#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>
#include <errno.h>

#define T0 1.0
#define TS 0.5

void sleepd(double time) {
	struct timespec ts;

    ts.tv_sec = time;
    ts.tv_nsec = (time - ts.tv_sec) * 1000000000;

    nanosleep(&ts, NULL);
}

void sleepkek(int i) {
	sleepd(T0 + TS*i);

	while(1) {
		int r = rand() % 129;
		if(r > 0 && r < 17) {
			pid_t thisProcess = getpid();
			kill(thisProcess, r);
		}

		if(r < 64) 
			exit(r);
	}
}

int main(int argc, char* argv[]) {
	if(argc != 2) {
		printf("Usage: %s <amount of processess>\n", argv[0]);
		return 1;
	}

	char* end;
	int amount = strtol(argv[1], &end, 10);

	if( amount < 1 || *end != '\0') {
		errno = 22;
		perror("Invalid input");
		return 2;
	} 
	
	for(int i = 0; i < amount; i++) {

		pid_t p = fork();

		if(p < 0) perror("Creating process failed\n");
		
		if(p > 0) {
			int status;
			pid_t child = wait(&status);
			if(child == -1) 
				perror("Wait failed\n");
			else if(WIFEXITED(status)) 
				printf("Child process pid: %d, exited with: %d\n", child, WEXITSTATUS(status));
			else if(WIFSIGNALED(status)) 
				printf("Child process pid: %d, killed with: %d\n", child, WTERMSIG(status));

			srand((unsigned int)p);
			
			sleepkek(i);			
		} 

		if(p == 0 && i == amount - 1) {
			srand((unsigned int)time(NULL));
			sleepkek(i + 1);
		}
	}

	return 0;

}
